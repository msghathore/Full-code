import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import Header from "@/components/Layout/Header";
import Footer from "@/components/Layout/Footer";
import FloatingElements from "@/components/3D/FloatingElements";
import { Clock, DollarSign } from "lucide-react";

const Services = () => {
  const [user, setUser] = useState(null);
  const [services, setServices] = useState([]);
  const [filter, setFilter] = useState("all");
  const navigate = useNavigate();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    const fetchServices = async () => {
      const { data, error } = await supabase
        .from("services")
        .select("*")
        .eq("is_active", true)
        .order("category");

      if (error) {
        console.error("Error fetching services:", error);
      } else {
        setServices(data || []);
      }
    };

    fetchServices();
  }, []);

  const categories = ["all", "hair", "nails", "tattoo", "piercing", "skin", "massage", "waxing"];

  const filteredServices = filter === "all" 
    ? services 
    : services.filter(s => s.category === filter);

  return (
    <div className="min-h-screen bg-background">
      <FloatingElements />
      <Header user={user} />
      
      <div className="pt-32 pb-20 px-4">
        <div className="container mx-auto">
          <h1 className="text-5xl md:text-7xl font-serif text-center mb-4 glow-text">
            Signature Services
          </h1>
          <p className="text-center text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">
            Curated experiences designed for the discerning individual
          </p>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {categories.map((cat) => (
              <Button
                key={cat}
                variant={filter === cat ? "default" : "outline"}
                onClick={() => setFilter(cat)}
                className={filter === cat ? "glow-button" : ""}
              >
                {cat.charAt(0).toUpperCase() + cat.slice(1)}
              </Button>
            ))}
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredServices.map((service) => (
              <Card
                key={service.id}
                className="overflow-hidden border-border hover:border-primary transition-all duration-300 glow-border"
              >
                <div className="p-6">
                  <h3 className="text-2xl font-serif mb-3">{service.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    {service.description}
                  </p>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="w-4 h-4" />
                      <span>{service.duration_minutes} min</span>
                    </div>
                    <div className="flex items-center gap-2 text-lg font-semibold">
                      <DollarSign className="w-5 h-5" />
                      <span>{service.price}</span>
                    </div>
                  </div>
                  <Button
                    onClick={() => navigate("/booking")}
                    className="w-full glow-button"
                  >
                    Book Now
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Services;

import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import Header from "@/components/Layout/Header";
import Footer from "@/components/Layout/Footer";
import FloatingElements from "@/components/3D/FloatingElements";
import { Card } from "@/components/ui/card";
import { Award, Users, Heart, Sparkles } from "lucide-react";

const About = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });
  }, []);

  const values = [
    {
      icon: <Award className="w-8 h-8" />,
      title: "Excellence",
      description: "We deliver nothing but the highest quality services and products",
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Community",
      description: "Building lasting relationships with our clients and team",
    },
    {
      icon: <Heart className="w-8 h-8" />,
      title: "Care",
      description: "Your wellbeing and satisfaction are our top priorities",
    },
    {
      icon: <Sparkles className="w-8 h-8" />,
      title: "Innovation",
      description: "Staying ahead with the latest techniques and treatments",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <FloatingElements />
      <Header user={user} />
      
      <div className="pt-32 pb-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <h1 className="text-5xl font-serif text-center mb-4 glow-text">
            About Zavira
          </h1>
          <p className="text-center text-lg text-muted-foreground mb-12">
            Where luxury meets expertise
          </p>

          <div className="prose prose-invert max-w-none mb-16">
            <p className="text-lg text-center mb-8">
              Zavira Salon & Spa is Winnipeg's premier destination for luxury beauty and wellness services.
              Founded with a vision to create a sanctuary where artistry meets excellence, we've been
              serving discerning clients for over a decade.
            </p>
            <p className="text-lg text-center">
              Our team of master stylists, tattoo artists, and wellness professionals bring decades
              of combined experience and a passion for perfection to every service we provide.
            </p>
          </div>

          <h2 className="text-3xl font-serif text-center mb-8">Our Values</h2>
          <div className="grid md:grid-cols-2 gap-6 mb-16">
            {values.map((value) => (
              <Card key={value.title} className="p-6 glow-border">
                <div className="text-primary mb-4">{value.icon}</div>
                <h3 className="text-xl font-serif mb-2">{value.title}</h3>
                <p className="text-muted-foreground">{value.description}</p>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <h2 className="text-3xl font-serif mb-4">Visit Us</h2>
            <p className="text-lg text-muted-foreground mb-2">253 Techs Avenue, Winnipeg, MB</p>
            <p className="text-lg text-muted-foreground">Open 7 Days: 9:00 AM - 11:30 PM</p>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default About;

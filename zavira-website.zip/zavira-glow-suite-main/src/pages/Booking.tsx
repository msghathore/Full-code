import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/Layout/Header";
import Footer from "@/components/Layout/Footer";
import FloatingElements from "@/components/3D/FloatingElements";
import { Clock, DollarSign } from "lucide-react";

const Booking = () => {
  const [user, setUser] = useState<any>(null);
  const [services, setServices] = useState([]);
  const [selectedService, setSelectedService] = useState<any>(null);
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const availableTimes = [
    "9:00 AM", "10:00 AM", "12:00 PM", "2:00 PM",
    "4:00 PM", "6:00 PM", "8:00 PM"
  ];

  useEffect(() => {
    const checkUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user ?? null);
    };
    checkUser();

    const fetchServices = async () => {
      const { data } = await supabase
        .from("services")
        .select("*")
        .eq("is_active", true);
      setServices(data || []);
    };
    fetchServices();
  }, []);

  const handleBooking = async () => {
    if (!user) {
      toast({
        title: "Please sign in",
        description: "You need to be signed in to book an appointment",
        variant: "destructive",
      });
      navigate("/auth");
      return;
    }

    if (!selectedService || !selectedDate || !selectedTime) {
      toast({
        title: "Missing information",
        description: "Please select a service, date, and time",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      const depositAmount = selectedService.price * 0.5;
      
      const { error } = await supabase.from("appointments").insert({
        user_id: user.id,
        service_id: selectedService.id,
        appointment_date: selectedDate.toISOString().split('T')[0],
        appointment_time: selectedTime,
        total_amount: selectedService.price,
        deposit_amount: depositAmount,
        status: "pending",
        payment_status: "pending",
      });

      if (error) throw error;

      toast({
        title: "Booking successful!",
        description: `Your ${selectedService.name} appointment is pending. We'll send payment details shortly.`,
      });

      navigate("/dashboard");
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <FloatingElements />
      <Header user={user} />
      
      <div className="pt-32 pb-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-5xl font-serif text-center mb-4 glow-text">
            Book Your Experience
          </h1>
          <p className="text-center text-lg text-muted-foreground mb-12">
            Select your desired service and preferred time
          </p>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Services Selection */}
            <div>
              <h2 className="text-2xl font-serif mb-6">SELECT YOUR SERVICE</h2>
              <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                {services.map((service: any) => (
                  <Card
                    key={service.id}
                    className={`p-4 cursor-pointer transition-all ${
                      selectedService?.id === service.id
                        ? "border-primary glow-border"
                        : "border-border"
                    }`}
                    onClick={() => setSelectedService(service)}
                  >
                    <h3 className="font-semibold mb-2">{service.name}</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      {service.description}
                    </p>
                    <div className="flex justify-between items-center text-sm">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        {service.duration_minutes} min
                      </div>
                      <div className="flex items-center gap-1 font-semibold">
                        <DollarSign className="w-4 h-4" />
                        {service.price}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>

            {/* Date & Time Selection */}
            <div>
              <h2 className="text-2xl font-serif mb-6">SELECT DATE & TIME</h2>
              <Card className="p-6 glow-border mb-6">
                <Label className="mb-4 block">Date</Label>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  disabled={(date) => date < new Date()}
                  className="rounded-md border"
                />
              </Card>

              <Card className="p-6 glow-border">
                <Label className="mb-4 block">Available Times</Label>
                <div className="grid grid-cols-3 gap-3">
                  {availableTimes.map((time) => (
                    <Button
                      key={time}
                      variant={selectedTime === time ? "default" : "outline"}
                      className={selectedTime === time ? "glow-button" : ""}
                      onClick={() => setSelectedTime(time)}
                    >
                      {time}
                    </Button>
                  ))}
                </div>
              </Card>

              {selectedService && selectedDate && selectedTime && (
                <Card className="p-6 mt-6 bg-card/50">
                  <h3 className="font-semibold mb-4">Booking Summary</h3>
                  <div className="space-y-2 text-sm mb-4">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Service:</span>
                      <span>{selectedService.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Date:</span>
                      <span>{selectedDate.toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Time:</span>
                      <span>{selectedTime}</span>
                    </div>
                    <div className="flex justify-between pt-2 border-t">
                      <span className="text-muted-foreground">Total:</span>
                      <span className="font-semibold">${selectedService.price}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Deposit (50%):</span>
                      <span className="font-semibold">${(selectedService.price * 0.5).toFixed(2)}</span>
                    </div>
                  </div>
                  <Button
                    onClick={handleBooking}
                    disabled={loading}
                    className="w-full glow-button"
                  >
                    {loading ? "Processing..." : "Confirm & Pay Deposit"}
                  </Button>
                  <p className="text-xs text-center text-muted-foreground mt-2">
                    50% deposit required to secure your appointment
                  </p>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Booking;

import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import Header from "@/components/Layout/Header";
import Footer from "@/components/Layout/Footer";
import FloatingElements from "@/components/3D/FloatingElements";
import { Calendar, ShoppingBag, User } from "lucide-react";

const Dashboard = () => {
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);
  const [appointments, setAppointments] = useState([]);
  const [orders, setOrders] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const checkUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/auth");
        return;
      }
      setUser(session.user);

      // Fetch profile
      const { data: profileData } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", session.user.id)
        .single();
      setProfile(profileData);

      // Fetch appointments
      const { data: appointmentsData } = await supabase
        .from("appointments")
        .select(`
          *,
          services (name, price)
        `)
        .eq("user_id", session.user.id)
        .order("appointment_date", { ascending: false })
        .limit(5);
      setAppointments(appointmentsData || []);

      // Fetch orders
      const { data: ordersData } = await supabase
        .from("orders")
        .select("*")
        .eq("user_id", session.user.id)
        .order("created_at", { ascending: false })
        .limit(5);
      setOrders(ordersData || []);
    };

    checkUser();
  }, [navigate]);

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background">
      <FloatingElements />
      <Header user={user} />
      
      <div className="pt-32 pb-20 px-4">
        <div className="container mx-auto">
          <h1 className="text-5xl font-serif mb-8 glow-text">My Dashboard</h1>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <Card className="p-6 glow-border">
              <div className="flex items-center gap-4">
                <User className="w-8 h-8 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Profile</p>
                  <p className="text-2xl font-semibold">{profile?.full_name || user.email}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6 glow-border">
              <div className="flex items-center gap-4">
                <Calendar className="w-8 h-8 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Appointments</p>
                  <p className="text-2xl font-semibold">{appointments.length}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6 glow-border">
              <div className="flex items-center gap-4">
                <ShoppingBag className="w-8 h-8 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Orders</p>
                  <p className="text-2xl font-semibold">{orders.length}</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Recent Appointments */}
          <div className="mb-12">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-3xl font-serif">Recent Appointments</h2>
              <Button onClick={() => navigate("/booking")} className="glow-button">
                Book New
              </Button>
            </div>
            <div className="grid gap-4">
              {appointments.length > 0 ? (
                appointments.map((apt: any) => (
                  <Card key={apt.id} className="p-6 glow-border">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-xl font-semibold mb-2">{apt.services?.name}</h3>
                        <p className="text-sm text-muted-foreground">
                          {new Date(apt.appointment_date).toLocaleDateString()} at {apt.appointment_time}
                        </p>
                        <p className="text-sm mt-2">
                          Status: <span className="capitalize">{apt.status}</span>
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-semibold">${apt.total_amount}</p>
                        <p className="text-xs text-muted-foreground">
                          {apt.payment_status === 'paid' ? 'Paid' : 'Pending'}
                        </p>
                      </div>
                    </div>
                  </Card>
                ))
              ) : (
                <Card className="p-6 text-center text-muted-foreground">
                  No appointments yet. Book your first service today!
                </Card>
              )}
            </div>
          </div>

          {/* Recent Orders */}
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-3xl font-serif">Purchase History</h2>
              <Button onClick={() => navigate("/shop")} variant="outline" className="glow-border">
                Shop Now
              </Button>
            </div>
            <div className="grid gap-4">
              {orders.length > 0 ? (
                orders.map((order: any) => (
                  <Card key={order.id} className="p-6 glow-border">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm text-muted-foreground">Order #{order.id.slice(0, 8)}</p>
                        <p className="text-sm">
                          {new Date(order.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-semibold">${order.total_amount}</p>
                        <p className="text-xs text-muted-foreground capitalize">{order.status}</p>
                      </div>
                    </div>
                  </Card>
                ))
              ) : (
                <Card className="p-6 text-center text-muted-foreground">
                  No orders yet. Check out our shop!
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Dashboard;

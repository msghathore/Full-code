import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useTranslation } from "react-i18next";
import Header from "@/components/Layout/Header";
import Footer from "@/components/Layout/Footer";
import FloatingElements from "@/components/3D/FloatingElements";
import ChatWidget from "@/components/Chat/ChatWidget";
import ProductAccordion from "@/components/ProductAccordion";
import TestimonialsCarousel from "@/components/TestimonialsCarousel";
import heroImage from "@/assets/hero-salon.jpg";
import nailsImage from "@/assets/nails-service.jpg";
import tattooImage from "@/assets/tattoo-service.jpg";
import skinImage from "@/assets/skin-service.jpg";

const Index = () => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();
  const { t } = useTranslation();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const services = [
    {
      name: "Hair",
      image: heroImage,
      description: "Expert styling & coloring",
    },
    {
      name: "Nails",
      image: nailsImage,
      description: "Luxury manicures & art",
    },
    {
      name: "Tattoo",
      image: tattooImage,
      description: "Custom ink & designs",
    },
    {
      name: "Skin",
      image: skinImage,
      description: "Advanced facial treatments",
    },
  ];

  return (
    <div className="min-h-screen bg-black">
      <FloatingElements />
      <Header user={user} />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 bg-black">
        <div className="container mx-auto text-center">
          <h1 className="text-6xl md:text-8xl font-serif mb-6 text-white" style={{ fontFamily: 'Garamond, serif', letterSpacing: '0.15em', textShadow: '0 0 40px rgba(255,255,255,0.2)' }}>
            {t('hero.title')}
          </h1>
          <p className="text-xl md:text-2xl tracking-widest text-white/60 mb-12" style={{ fontFamily: 'Garamond, serif' }}>
            {t('hero.subtitle')}
          </p>
          <p className="text-lg max-w-2xl mx-auto mb-12 text-white/70 leading-relaxed">
            Experience luxury wellness and beauty services crafted for the discerning individual.
            Where artistry meets excellence.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={() => navigate("/booking")}
              size="lg"
              className="text-lg px-8 py-6 bg-white text-black font-serif font-semibold tracking-widest hover:bg-white/90 transition-all"
              style={{ fontFamily: 'Garamond, serif' }}
            >
              {t('hero.cta')}
            </Button>
            <Button
              onClick={() => navigate("/services")}
              size="lg"
              variant="outline"
              className="text-lg px-8 py-6 border-white text-white hover:bg-white/10 transition-all"
              style={{ fontFamily: 'Garamond, serif' }}
            >
              EXPLORE SERVICES
            </Button>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 px-4 bg-black">
        <div className="container mx-auto">
          <h2 className="text-5xl font-serif text-center mb-12 text-white" style={{ fontFamily: 'Garamond, serif', letterSpacing: '0.05em', textShadow: '0 0 30px rgba(255,255,255,0.1)' }}>
            {t('services.title')}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service) => (
              <Card
                key={service.name}
                className="group cursor-pointer overflow-hidden border-white/20 hover:border-white/40 transition-all duration-300 bg-white/5 hover:bg-white/10"
                onClick={() => navigate("/services")}
              >
                <div className="aspect-square overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-serif mb-2 text-white" style={{ fontFamily: 'Garamond, serif' }}>{service.name}</h3>
                  <p className="text-sm text-white/60">{service.description}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <TestimonialsCarousel />

      {/* Products Section */}
      <ProductAccordion />

      <ChatWidget />
      <Footer />
    </div>
  );
};

export default Index;

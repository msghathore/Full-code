import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import Header from "@/components/Layout/Header";
import Footer from "@/components/Layout/Footer";
import FloatingElements from "@/components/3D/FloatingElements";
import { ShoppingCart, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Shop = () => {
  const [user, setUser] = useState(null);
  const [products, setProducts] = useState([]);
  const { toast } = useToast();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const fetchProducts = async () => {
      const { data } = await supabase
        .from("products")
        .select("*")
        .eq("is_active", true);
      setProducts(data || []);
    };
    fetchProducts();
  }, []);

  const handleAddToCart = (product: any) => {
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <FloatingElements />
      <Header user={user} />
      
      <div className="pt-32 pb-20 px-4">
        <div className="container mx-auto">
          <h1 className="text-5xl font-serif text-center mb-4 glow-text">
            Luxury Products
          </h1>
          <p className="text-center text-lg text-muted-foreground mb-12">
            Professional-grade products for at-home care
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product: any) => (
              <Card key={product.id} className="overflow-hidden glow-border">
                <div className="aspect-square bg-secondary" />
                <div className="p-6">
                  <h3 className="text-xl font-serif mb-2">{product.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    {product.description}
                  </p>
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-accent text-accent" />
                    ))}
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-2xl font-semibold">${product.price}</span>
                    <Button
                      onClick={() => handleAddToCart(product)}
                      className="glow-button"
                    >
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      Add to Cart
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Shop;

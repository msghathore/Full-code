import { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Star } from 'lucide-react';

interface Testimonial {
  name: string;
  quote: string;
  rating: number;
}

const TestimonialsCarousel = () => {
  const { t } = useTranslation();
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const testimonials: Testimonial[] = [
    {
      name: t('testimonials.name1'),
      quote: t('testimonials.testimonial1'),
      rating: 5,
    },
    {
      name: t('testimonials.name2'),
      quote: t('testimonials.testimonial2'),
      rating: 5,
    },
    {
      name: t('testimonials.name3'),
      quote: t('testimonials.testimonial3'),
      rating: 5,
    },
  ];

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    let scrollPosition = 0;
    const scrollSpeed = 1;
    let animationId: number;

    const scroll = () => {
      scrollPosition += scrollSpeed;
      if (scrollPosition > container.scrollWidth - container.clientWidth) {
        scrollPosition = 0;
      }
      container.scrollLeft = scrollPosition;
      animationId = requestAnimationFrame(scroll);
    };

    animationId = requestAnimationFrame(scroll);

    const handleMouseEnter = () => cancelAnimationFrame(animationId);
    const handleMouseLeave = () => {
      animationId = requestAnimationFrame(scroll);
    };

    container.addEventListener('mouseenter', handleMouseEnter);
    container.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      cancelAnimationFrame(animationId);
      container.removeEventListener('mouseenter', handleMouseEnter);
      container.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  return (
    <section className="py-20 px-4 bg-black overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <h2 className="font-serif text-5xl text-white text-center mb-16" style={{ fontFamily: 'Garamond, serif', letterSpacing: '0.05em', textShadow: '0 0 30px rgba(255,255,255,0.1)' }}>
          {t('testimonials.title')}
        </h2>

        <div
          ref={scrollContainerRef}
          className="flex gap-6 overflow-x-hidden scroll-smooth"
          style={{ scrollBehavior: 'smooth' }}
        >
          {[...testimonials, ...testimonials].map((testimonial, idx) => (
            <div
              key={idx}
              className="flex-shrink-0 w-96 bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-xl border border-white/20 rounded-2xl p-8 hover:from-white/15 hover:to-white/10 transition-all duration-300 transform hover:scale-105"
            >
              <div className="flex gap-2 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star
                    key={i}
                    size={18}
                    className="fill-yellow-400 text-yellow-400"
                  />
                ))}
              </div>

              <p className="text-white/90 mb-6 leading-relaxed italic text-lg">
                "{testimonial.quote}"
              </p>

              <p className="font-serif text-white" style={{ fontFamily: 'Garamond, serif', fontSize: '1.1rem', letterSpacing: '0.05em' }}>
                {testimonial.name}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsCarousel;

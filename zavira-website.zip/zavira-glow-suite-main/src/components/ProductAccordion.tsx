import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import hairCareImg from '@/assets/skin-service.jpg';
import skincareImg from '@/assets/skin-service.jpg';
import nailsImg from '@/assets/nails-service.jpg';
import accessoriesImg from '@/assets/tattoo-service.jpg';

interface Product {
  id: string;
  name: string;
  image: string;
  description: string;
}

const ProductAccordion = () => {
  const { t } = useTranslation();
  const [expandedId, setExpandedId] = useState('nails');

  const products: Product[] = [
    {
      id: 'hair',
      name: t('products.haircare'),
      image: hairCareImg,
      description: 'Premium hair treatments and care products for all hair types.',
    },
    {
      id: 'skin',
      name: t('products.skincare'),
      image: skincareImg,
      description: 'Luxurious skincare essentials for radiant, healthy skin.',
    },
    {
      id: 'nails',
      name: t('products.nails'),
      image: nailsImg,
      description: 'Professional nail care and polish for beautiful nails.',
    },
    {
      id: 'accessories',
      name: t('products.accessories'),
      image: accessoriesImg,
      description: 'Elegant accessories to elevate your beauty routine.',
    },
  ];

  return (
    <section className="py-20 px-4 bg-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-serif text-5xl text-white mb-4" style={{ fontFamily: 'Garamond, serif', letterSpacing: '0.05em', textShadow: '0 0 30px rgba(255,255,255,0.1)' }}>
            {t('products.title')}
          </h2>
          <p className="text-white/60 text-lg" style={{ fontFamily: 'Garamond, serif' }}>
            {t('products.subtitle')}
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 auto-rows-max">
          {products.map((product, index) => (
            <div
              key={product.id}
              className={`relative rounded-2xl overflow-hidden cursor-pointer transition-all duration-500 group ${
                expandedId === product.id
                  ? 'lg:col-span-2 lg:row-span-2'
                  : 'col-span-1'
              }`}
              onMouseEnter={() => setExpandedId(product.id)}
              style={{
                minHeight: expandedId === product.id ? '400px' : '200px',
              }}
            >
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              <div className="absolute inset-0 flex flex-col justify-end p-6 text-white transform transition-all duration-500">
                <h3 className="font-serif text-2xl mb-2" style={{ fontFamily: 'Garamond, serif', letterSpacing: '0.05em' }}>
                  {product.name}
                </h3>

                {expandedId === product.id && (
                  <p className="text-white/80 text-sm leading-relaxed animate-in fade-in duration-300">
                    {product.description}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductAccordion;

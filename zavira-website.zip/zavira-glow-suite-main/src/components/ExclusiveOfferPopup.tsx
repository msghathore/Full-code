import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const ExclusiveOfferPopup = () => {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(true);
  const [phoneInput, setPhoneInput] = useState('');

  useEffect(() => {
    const hasSeenPopup = localStorage.getItem('zaviraPopupSeen');
    if (!hasSeenPopup) {
      setIsOpen(true);
      localStorage.setItem('zaviraPopupSeen', 'true');
    } else {
      setIsOpen(false);
    }
  }, []);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/40 backdrop-blur-sm">
      <div className="backdrop-blur-xl bg-white/8 rounded-3xl p-12 border border-white/20 max-w-md w-full mx-4 relative shadow-2xl"
        style={{ animation: 'slideUp 0.6s ease-out' }}>

        <button
          onClick={() => setIsOpen(false)}
          className="absolute top-6 right-6 text-white/60 hover:text-white transition-colors"
        >
          <X size={24} />
        </button>

        <div className="text-center mb-8">
          <h2 className="font-serif text-4xl text-white mb-2" style={{ fontFamily: 'Garamond, serif', letterSpacing: '0.05em', textShadow: '0 0 20px rgba(255,255,255,0.2)' }}>
            Zavira
          </h2>
          <p className="text-white/60 text-sm tracking-widest">SALON & SPA</p>
        </div>

        <h3 className="font-serif text-2xl text-white text-center mb-4" style={{ fontFamily: 'Garamond, serif' }}>
          {t('popup.title')}
        </h3>

        <p className="text-white/70 text-center mb-8 leading-relaxed">
          {t('popup.subtitle')}
        </p>

        <input
          type="tel"
          placeholder="+1 (431) 866-4545"
          value={phoneInput}
          onChange={(e) => setPhoneInput(e.target.value)}
          className="w-full px-6 py-3 rounded-full bg-white/10 border border-white/20 text-white placeholder:text-white/40 focus:outline-none focus:border-white/40 transition-colors mb-6"
        />

        <button
          onClick={() => {
            setIsOpen(false);
          }}
          className="w-full py-3 px-6 rounded-full bg-white text-black font-serif font-semibold tracking-wider hover:bg-white/90 transition-all transform hover:scale-105 active:scale-95"
          style={{ fontFamily: 'Garamond, serif' }}
        >
          {t('popup.button')}
        </button>

        <p className="text-white/50 text-xs text-center mt-6">
          {t('popup.privacy')}
        </p>
      </div>

      <style>{`
        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
};

export default ExclusiveOfferPopup;

import { useState, useEffect } from 'react';

const LoadingScreen = ({ isVisible }: { isVisible: boolean }) => {
  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90">
      <div className="backdrop-blur-sm bg-white/5 rounded-2xl p-12 border border-white/10 flex flex-col items-center gap-8">
        <h1 className="font-serif text-5xl tracking-wide text-white" style={{ fontFamily: 'Garamond, serif', letterSpacing: '0.2em', textShadow: '0 0 20px rgba(255,255,255,0.3)' }}>
          Zavira
        </h1>

        <div className="w-12 h-12 relative">
          <svg className="w-full h-full" viewBox="0 0 50 50">
            <circle cx="25" cy="25" r="20" fill="none" stroke="url(#grad1)" strokeWidth="2" strokeDasharray="125.6" strokeDashoffset="0" style={{ animation: 'spin 2s linear infinite' }} />
            <defs>
              <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="rgba(255,255,255,0.8)" />
                <stop offset="100%" stopColor="rgba(255,255,255,0.2)" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>

      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default LoadingScreen;

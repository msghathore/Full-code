import { useEffect, useState } from 'react';

const CustomCursor = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isHoveringClickable, setIsHoveringClickable] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });

      const target = e.target as HTMLElement;
      const isClickable =
        target.tagName === 'A' ||
        target.tagName === 'BUTTON' ||
        target.closest('button') ||
        target.closest('a') ||
        target.onclick ||
        target.className?.includes('cursor-pointer');

      setIsHoveringClickable(!!isClickable);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <>
      <div
        className="fixed pointer-events-none z-50 transition-all duration-100"
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
          transform: 'translate(-50%, -50%)',
        }}
      >
        <div
          className={`transition-all duration-300 ${
            isHoveringClickable ? 'scale-150' : 'scale-100'
          }`}
          style={{
            width: '12px',
            height: '12px',
            border: '2px solid rgba(255,255,255,0.8)',
            borderRadius: '50%',
            boxShadow: '0 0 8px rgba(255,255,255,0.4)',
          }}
        />
      </div>

      <div
        className="fixed pointer-events-none z-49"
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
          transform: 'translate(-50%, -50%)',
        }}
      >
        <div
          className={`transition-all duration-500 ${
            isHoveringClickable ? 'opacity-100 scale-100' : 'opacity-0 scale-0'
          }`}
          style={{
            width: '40px',
            height: '40px',
            border: '2px solid rgba(255,255,255,0.3)',
            borderRadius: '50%',
            boxShadow: '0 0 15px rgba(255,255,255,0.2)',
          }}
        />
      </div>

      <style>{`
        * {
          cursor: none !important;
        }
      `}</style>
    </>
  );
};

export default CustomCursor;

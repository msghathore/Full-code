const FloatingElements = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {/* Floating Glow Orbs */}
      <div className="absolute top-20 left-10 w-32 h-32 rounded-full bg-primary/10 blur-3xl animate-float" />
      <div className="absolute top-40 right-20 w-24 h-24 rounded-full bg-accent/10 blur-3xl animate-float-delayed" />
      <div className="absolute bottom-20 left-1/4 w-40 h-40 rounded-full bg-primary/5 blur-3xl animate-float" />
      <div className="absolute bottom-40 right-1/3 w-28 h-28 rounded-full bg-accent/5 blur-3xl animate-float-delayed" />
      
      {/* Hair Dryer Icon */}
      <div className="absolute top-1/4 right-10 animate-float opacity-10">
        <svg width="80" height="80" viewBox="0 0 24 24" fill="none" className="text-primary">
          <path
            d="M7 12C7 10.895 7.895 10 9 10H12C13.105 10 14 10.895 14 12V20H7V12Z"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          />
          <circle cx="10.5" cy="6" r="5" stroke="currentColor" strokeWidth="2" />
          <line x1="10.5" y1="1" x2="10.5" y2="3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </div>
      
      {/* Nail Polish Icon */}
      <div className="absolute bottom-1/4 left-20 animate-float-delayed opacity-10">
        <svg width="60" height="60" viewBox="0 0 24 24" fill="none" className="text-accent">
          <path
            d="M9 3L15 3C15.55 3 16 3.45 16 4V8H8V4C8 3.45 8.45 3 9 3Z"
            stroke="currentColor"
            strokeWidth="2"
          />
          <path
            d="M8 8H16V12C16 16 12 21 12 21C12 21 8 16 8 12V8Z"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      
      {/* Tattoo Machine Icon */}
      <div className="absolute top-1/3 left-1/4 animate-float opacity-10">
        <svg width="70" height="70" viewBox="0 0 24 24" fill="none" className="text-primary">
          <path
            d="M4 20L8 16L12 20L16 16L20 20"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M12 4V16"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          />
          <circle cx="12" cy="4" r="2" stroke="currentColor" strokeWidth="2" />
        </svg>
      </div>
      
      {/* Sparkle Elements */}
      <div className="absolute top-1/2 right-1/4 opacity-20 animate-glow-pulse">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="currentColor" className="text-accent">
          <path d="M12 0L14.59 9.41L24 12L14.59 14.59L12 24L9.41 14.59L0 12L9.41 9.41L12 0Z" />
        </svg>
      </div>
      
      <div className="absolute bottom-1/3 right-1/3 opacity-15 animate-glow-pulse" style={{ animationDelay: '1s' }}>
        <svg width="30" height="30" viewBox="0 0 24 24" fill="currentColor" className="text-primary">
          <path d="M12 0L14.59 9.41L24 12L14.59 14.59L12 24L9.41 14.59L0 12L9.41 9.41L12 0Z" />
        </svg>
      </div>
    </div>
  );
};

export default FloatingElements;

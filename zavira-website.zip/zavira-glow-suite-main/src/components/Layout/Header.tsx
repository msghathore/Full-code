import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X, User, LogOut, Home, Briefcase, ShoppingBag, BookOpen, Info, Mail } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "react-i18next";

interface HeaderProps {
  user: any;
}

const Header = ({ user }: HeaderProps) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { t } = useTranslation();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast({
      title: "Logged out successfully",
    });
    navigate("/");
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/40 backdrop-blur-xl border-b border-white/10">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex flex-col">
            <h1 className="text-3xl font-serif text-white" style={{ fontFamily: 'Garamond, serif', letterSpacing: '0.1em', textShadow: '0 0 20px rgba(255,255,255,0.3)' }}>Zavira</h1>
            <span className="text-xs tracking-widest text-white/60">SALON & SPA</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link to="/services" className="flex items-center gap-2 text-sm tracking-widest text-white/80 hover:text-white transition-all hover:translate-y-[-2px] group" style={{ fontFamily: 'Garamond, serif' }}>
              <Briefcase className="w-4 h-4 group-hover:scale-110 transition-transform" />
              {t('nav.services')}
            </Link>
            <Link to="/booking" className="flex items-center gap-2 text-sm tracking-widest text-white/80 hover:text-white transition-all hover:translate-y-[-2px] group" style={{ fontFamily: 'Garamond, serif' }}>
              <Home className="w-4 h-4 group-hover:scale-110 transition-transform" />
              {t('nav.booking')}
            </Link>
            <Link to="/shop" className="flex items-center gap-2 text-sm tracking-widest text-white/80 hover:text-white transition-all hover:translate-y-[-2px] group" style={{ fontFamily: 'Garamond, serif' }}>
              <ShoppingBag className="w-4 h-4 group-hover:scale-110 transition-transform" />
              {t('nav.shop')}
            </Link>
            <Link to="/blog" className="flex items-center gap-2 text-sm tracking-widest text-white/80 hover:text-white transition-all hover:translate-y-[-2px] group" style={{ fontFamily: 'Garamond, serif' }}>
              <BookOpen className="w-4 h-4 group-hover:scale-110 transition-transform" />
              {t('nav.blog')}
            </Link>
            <Link to="/about" className="flex items-center gap-2 text-sm tracking-widest text-white/80 hover:text-white transition-all hover:translate-y-[-2px] group" style={{ fontFamily: 'Garamond, serif' }}>
              <Info className="w-4 h-4 group-hover:scale-110 transition-transform" />
              {t('nav.about')}
            </Link>
            <Link to="/contact" className="flex items-center gap-2 text-sm tracking-widest text-white/80 hover:text-white transition-all hover:translate-y-[-2px] group" style={{ fontFamily: 'Garamond, serif' }}>
              <Mail className="w-4 h-4 group-hover:scale-110 transition-transform" />
              {t('nav.contact')}
            </Link>
          </nav>

          {/* User Actions */}
          <div className="hidden md:flex items-center gap-4">
            {user ? (
              <>
                <button
                  onClick={() => navigate("/dashboard")}
                  className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center text-white/60 hover:text-white hover:border-white/60 transition-all hover:bg-white/5"
                >
                  <User className="w-5 h-5" />
                </button>
                <button onClick={handleLogout} className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center text-white/60 hover:text-white hover:border-white/60 transition-all hover:bg-white/5">
                  <LogOut className="w-5 h-5" />
                </button>
              </>
            ) : (
              <Button
                onClick={() => navigate("/auth")}
                className="px-6 py-2 rounded-full bg-white text-black font-serif font-semibold tracking-widest hover:bg-white/90 transition-all"
                style={{ fontFamily: 'Garamond, serif' }}
              >
                Sign In
              </Button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-white"
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden border-t border-white/10 bg-black/60 backdrop-blur-xl">
          <nav className="flex flex-col gap-4 p-6">
            <Link
              to="/services"
              className="flex items-center gap-2 text-sm tracking-widest text-white/80 hover:text-white transition-colors"
              style={{ fontFamily: 'Garamond, serif' }}
              onClick={() => setIsMenuOpen(false)}
            >
              <Briefcase className="w-4 h-4" />
              {t('nav.services')}
            </Link>
            <Link
              to="/booking"
              className="flex items-center gap-2 text-sm tracking-widest text-white/80 hover:text-white transition-colors"
              style={{ fontFamily: 'Garamond, serif' }}
              onClick={() => setIsMenuOpen(false)}
            >
              <Home className="w-4 h-4" />
              {t('nav.booking')}
            </Link>
            <Link
              to="/shop"
              className="flex items-center gap-2 text-sm tracking-widest text-white/80 hover:text-white transition-colors"
              style={{ fontFamily: 'Garamond, serif' }}
              onClick={() => setIsMenuOpen(false)}
            >
              <ShoppingBag className="w-4 h-4" />
              {t('nav.shop')}
            </Link>
            <Link
              to="/blog"
              className="flex items-center gap-2 text-sm tracking-widest text-white/80 hover:text-white transition-colors"
              style={{ fontFamily: 'Garamond, serif' }}
              onClick={() => setIsMenuOpen(false)}
            >
              <BookOpen className="w-4 h-4" />
              {t('nav.blog')}
            </Link>
            <Link
              to="/about"
              className="flex items-center gap-2 text-sm tracking-widest text-white/80 hover:text-white transition-colors"
              style={{ fontFamily: 'Garamond, serif' }}
              onClick={() => setIsMenuOpen(false)}
            >
              <Info className="w-4 h-4" />
              {t('nav.about')}
            </Link>
            <Link
              to="/contact"
              className="flex items-center gap-2 text-sm tracking-widest text-white/80 hover:text-white transition-colors"
              style={{ fontFamily: 'Garamond, serif' }}
              onClick={() => setIsMenuOpen(false)}
            >
              <Mail className="w-4 h-4" />
              {t('nav.contact')}
            </Link>
            {user ? (
              <>
                <Link
                  to="/dashboard"
                  className="flex items-center gap-2 text-sm tracking-widest text-white/80 hover:text-white transition-colors"
                  style={{ fontFamily: 'Garamond, serif' }}
                  onClick={() => setIsMenuOpen(false)}
                >
                  <User className="w-4 h-4" />
                  DASHBOARD
                </Link>
                <button
                  onClick={() => {
                    handleLogout();
                    setIsMenuOpen(false);
                  }}
                  className="flex items-center gap-2 text-sm tracking-widest text-white/80 hover:text-white transition-colors text-left"
                  style={{ fontFamily: 'Garamond, serif' }}
                >
                  <LogOut className="w-4 h-4" />
                  LOGOUT
                </button>
              </>
            ) : (
              <Button
                onClick={() => {
                  navigate("/auth");
                  setIsMenuOpen(false);
                }}
                className="w-full mt-4 px-6 py-2 rounded-full bg-white text-black font-serif font-semibold tracking-widest hover:bg-white/90 transition-all"
                style={{ fontFamily: 'Garamond, serif' }}
              >
                Sign In
              </Button>
            )}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;

import { Link } from "react-router-dom";
import { Instagram, Facebook, Twitter, Youtube, Linkedin, Share2, MapPin } from "lucide-react";
import { useTranslation } from "react-i18next";
import { useEffect, useState } from "react";

const Footer = () => {
  const { t, i18n } = useTranslation();
  const [mapLoaded, setMapLoaded] = useState(false);

  const toggleLanguage = () => {
    const newLang = i18n.language === 'en' ? 'fr' : 'en';
    i18n.changeLanguage(newLang);
    localStorage.setItem('language', newLang);
  };

  return (
    <footer className="bg-black border-t border-white/10 mt-20">
      <div className="container mx-auto px-4 py-16">
        {/* Logo and Map Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12 pb-12 border-b border-white/10">
          {/* Brand with Shining Logo */}
          <div className="flex flex-col items-center justify-start md:items-start">
            <h3
              className="text-5xl font-serif text-white mb-2 animate-pulse"
              style={{
                fontFamily: 'Garamond, serif',
                letterSpacing: '0.1em',
                textShadow: '0 0 30px rgba(255,255,255,0.4), 0 0 60px rgba(255,255,255,0.2)',
              }}
            >
              Zavira
            </h3>
            <p className="text-xs tracking-widest text-white/60 mb-4">SALON & SPA</p>
          </div>

          {/* Map */}
          <div className="rounded-lg overflow-hidden border border-white/10 h-64">
            <iframe
              width="100%"
              height="100%"
              style={{ border: 'none' }}
              loading="lazy"
              allowFullScreen
              referrerPolicy="no-referrer-when-downgrade"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2832.5555555555555!2d-97.1411111!3d49.8865111!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x52ea7bffc1c1c1c1%3A0x1234567890!2s283%20Tache%20Avenue%2C%20Winnipeg%2C%20MB!5e0!3m2!1sen!2sca!4v1234567890"
              onLoad={() => setMapLoaded(true)}
            />
          </div>

          {/* Language Toggle */}
          <div className="flex flex-col items-center justify-start md:items-end">
            <button
              onClick={toggleLanguage}
              className="px-8 py-2 rounded-full border border-white/30 text-white hover:border-white/60 transition-all hover:bg-white/5 font-serif tracking-wider"
              style={{ fontFamily: 'Garamond, serif' }}
            >
              {i18n.language === 'en' ? 'ENGLISH' : 'FRANÇAIS'}
            </button>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* About */}
          <div>
            <h4 className="text-sm font-semibold mb-4 tracking-wider text-white" style={{ fontFamily: 'Garamond, serif' }}>
              {t('footer.about').toUpperCase()}
            </h4>
            <div className="flex flex-col gap-2">
              <a href="#" className="text-sm text-white/60 hover:text-white transition-colors">
                {t('footer.careers')}
              </a>
              <a href="#" className="text-sm text-white/60 hover:text-white transition-colors">
                {t('footer.guarantee')}
              </a>
            </div>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-sm font-semibold mb-4 tracking-wider text-white" style={{ fontFamily: 'Garamond, serif' }}>
              LEGAL
            </h4>
            <div className="flex flex-col gap-2">
              <a href="#" className="text-sm text-white/60 hover:text-white transition-colors">
                {t('footer.privacy')}
              </a>
              <a href="#" className="text-sm text-white/60 hover:text-white transition-colors">
                {t('footer.cookies')}
              </a>
              <a href="#" className="text-sm text-white/60 hover:text-white transition-colors">
                {t('footer.returns')}
              </a>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-semibold mb-4 tracking-wider text-white" style={{ fontFamily: 'Garamond, serif' }}>
              CONTACT
            </h4>
            <div className="flex flex-col gap-2 text-sm text-white/70">
              <p>{t('footer.address')}</p>
              <p>{t('footer.phone')}</p>
              <p className="flex items-center gap-2 mt-2">
                <MapPin className="w-4 h-4" />
                <span>{t('footer.hours')}</span>
              </p>
            </div>
          </div>

          {/* Social */}
          <div>
            <h4 className="text-sm font-semibold mb-4 tracking-wider text-white" style={{ fontFamily: 'Garamond, serif' }}>
              FOLLOW
            </h4>
            <div className="flex gap-3 flex-wrap">
              <a
                href="#"
                className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center text-white/60 hover:text-white hover:border-white/60 transition-all hover:bg-white/5"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center text-white/60 hover:text-white hover:border-white/60 transition-all hover:bg-white/5"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center text-white/60 hover:text-white hover:border-white/60 transition-all hover:bg-white/5"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center text-white/60 hover:text-white hover:border-white/60 transition-all hover:bg-white/5"
              >
                <Youtube className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center text-white/60 hover:text-white hover:border-white/60 transition-all hover:bg-white/5"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center text-white/60 hover:text-white hover:border-white/60 transition-all hover:bg-white/5"
              >
                <Share2 className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-white/10 text-center text-sm text-white/50">
          <p>{t('footer.copyright')}</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

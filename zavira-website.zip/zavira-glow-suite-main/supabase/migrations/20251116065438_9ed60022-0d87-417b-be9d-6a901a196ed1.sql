-- Create profiles table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  phone TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create services table
CREATE TABLE IF NOT EXISTS public.services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  duration_minutes INTEGER NOT NULL,
  image_url TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create appointments table
CREATE TABLE IF NOT EXISTS public.appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  service_id UUID REFERENCES public.services(id),
  appointment_date DATE NOT NULL,
  appointment_time TIME NOT NULL,
  status TEXT DEFAULT 'pending',
  payment_status TEXT DEFAULT 'pending',
  payment_intent_id TEXT,
  total_amount DECIMAL(10, 2),
  deposit_amount DECIMAL(10, 2),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create products table
CREATE TABLE IF NOT EXISTS public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  stock_quantity INTEGER DEFAULT 0,
  image_url TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create orders table
CREATE TABLE IF NOT EXISTS public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  total_amount DECIMAL(10, 2) NOT NULL,
  status TEXT DEFAULT 'pending',
  payment_intent_id TEXT,
  shipping_address TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create order_items table
CREATE TABLE IF NOT EXISTS public.order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id UUID REFERENCES public.products(id),
  quantity INTEGER NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create blog_posts table
CREATE TABLE IF NOT EXISTS public.blog_posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  excerpt TEXT,
  content TEXT NOT NULL,
  image_url TEXT,
  author_name TEXT DEFAULT 'Zavira Team',
  published_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  is_published BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blog_posts ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- Services policies (public read)
CREATE POLICY "Anyone can view active services"
  ON public.services FOR SELECT
  USING (is_active = true);

-- Appointments policies
CREATE POLICY "Users can view their own appointments"
  ON public.appointments FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own appointments"
  ON public.appointments FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own appointments"
  ON public.appointments FOR UPDATE
  USING (auth.uid() = user_id);

-- Products policies (public read)
CREATE POLICY "Anyone can view active products"
  ON public.products FOR SELECT
  USING (is_active = true);

-- Orders policies
CREATE POLICY "Users can view their own orders"
  ON public.orders FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own orders"
  ON public.orders FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Order items policies
CREATE POLICY "Users can view their order items"
  ON public.order_items FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.orders
    WHERE orders.id = order_items.order_id
    AND orders.user_id = auth.uid()
  ));

-- Blog posts policies (public read)
CREATE POLICY "Anyone can view published blog posts"
  ON public.blog_posts FOR SELECT
  USING (is_published = true);

-- Create profile trigger
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', '')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add updated_at triggers
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_appointments_updated_at
  BEFORE UPDATE ON public.appointments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_orders_updated_at
  BEFORE UPDATE ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_blog_posts_updated_at
  BEFORE UPDATE ON public.blog_posts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Insert mock services
INSERT INTO public.services (name, category, description, price, duration_minutes) VALUES
('Signature Haircut & Style', 'hair', 'Expert precision cutting with luxurious wash, conditioning treatment, and professional styling.', 85.00, 60),
('Balayage Color Treatment', 'hair', 'Hand-painted highlights for natural, sun-kissed dimension. Includes toner and conditioning treatment.', 285.00, 180),
('Luxury Gel Manicure', 'nails', 'Premium gel polish with nail shaping, cuticle care, hand massage, and long-lasting color.', 65.00, 60),
('Custom Tattoo Session', 'tattoo', 'Personalized tattoo design and application by our master artists. Price varies by size and complexity.', 200.00, 120),
('Piercing Service', 'piercing', 'Professional piercing with premium jewelry. Includes aftercare kit and consultation.', 75.00, 30),
('Diamond Facial', 'skin', 'Advanced microdermabrasion with diamond-tip technology, hydrating mask, and LED therapy.', 195.00, 90),
('Deep Tissue Massage', 'massage', 'Therapeutic full-body massage targeting tension and muscle knots. Includes aromatherapy.', 145.00, 90),
('Brazilian Wax', 'waxing', 'Professional hair removal using premium wax. Includes soothing aftercare treatment.', 75.00, 45),
('Spa Pedicure Deluxe', 'nails', 'Complete foot care with exfoliation, massage, paraffin treatment, and gel polish.', 85.00, 75);

-- Insert mock products
INSERT INTO public.products (name, category, description, price, stock_quantity) VALUES
('Luxury Hair Serum', 'hair-care', 'Nourishing serum with argan oil for silky, frizz-free hair.', 48.00, 50),
('Diamond Glow Facial Mask', 'skincare', 'Premium hydrating mask with diamond powder for radiant skin.', 65.00, 30),
('Professional Nail Care Kit', 'nail-care', 'Complete at-home manicure set with premium tools.', 85.00, 20),
('Tattoo Aftercare Balm', 'tattoo-care', 'Specialized healing balm for new tattoos with natural ingredients.', 28.00, 100),
('Luxury Body Oil', 'body-care', 'Hydrating massage oil with essential oils for smooth skin.', 42.00, 40);

-- Insert mock blog posts
INSERT INTO public.blog_posts (title, slug, excerpt, content) VALUES
('Top 5 Hair Care Tips for Winter', 'top-5-hair-care-tips-for-winter', 'Keep your locks healthy and beautiful during the cold months with these expert tips.', 'Winter can be harsh on your hair. Here are our top tips: 1) Use deep conditioning treatments weekly 2) Avoid excessive heat styling 3) Stay hydrated 4) Trim regularly 5) Use a humidifier at home. Your hair will thank you!'),
('The Art of Balayage: Everything You Need to Know', 'the-art-of-balayage-everything-you-need-to-know', 'Discover why balayage is the perfect technique for natural-looking highlights.', 'Balayage is a French hair coloring technique that creates natural-looking, sun-kissed highlights. Unlike traditional foiling, balayage is hand-painted for a more customized result. The benefits include less maintenance, softer grow-out, and a more natural appearance. Perfect for all hair types and colors!'),
('Skincare Routine: Morning vs Evening', 'skincare-routine-morning-vs-evening', 'Learn the essential differences between your AM and PM skincare routines.', 'Your skin has different needs throughout the day. Morning routines focus on protection with cleansing, antioxidants, and SPF. Evening routines emphasize repair with double cleansing, treatment serums, and rich moisturizers. Consistency is key to achieving that healthy glow!');
